package it.dogior.hadEnough.extractors

import com.lagradost.cloudstream3.extractors.MixDrop

class MixDropExtractor : MixDrop(){
    override var mainUrl = "https://m1xdrop.net"
}
